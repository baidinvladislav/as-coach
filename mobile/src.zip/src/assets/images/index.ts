export const BackgroundImage = require('./background.png');
export const BicepsImage = require('./biceps.png');
export const DefaultAvatarImage = require('./default-avatar.png');
