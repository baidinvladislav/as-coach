export const LoaderJSON = require('./loader.json');
